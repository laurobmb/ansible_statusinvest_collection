#!/usr/bin/python

ANSIBLE_METADATA = {
    'metadata_version': '1.0',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: demo_hello
short_description: A module that says hello in many languages
version_added: "2.8"
description:
  - "A module that says hello in many languages."
options:
    name:
        description:
          - Name of the person to salute. If no value is provided the default
            value will be used.
        required: false
        type: str
        default: John Doe
author:
    - Gianni Salinetti (@giannisalinetti)
'''

EXAMPLES = '''
# Pass in a custom name
- name: Say hello to Linus Torvalds
  demo_hello:
    name: "Linus Torvalds"
'''

RETURN = '''
fact:
  description: Hello string
  type: str
  sample: Hello John Doe!
'''

import random
from ansible.module_utils.basic import AnsibleModule
from lxml import html
import requests, sys

def statusinvest_acoes(ACOES):
    acoes = ACOES
    percentagem_dividendo, cotacao_atual = '0','0'
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    try:
        page = requests.get('https://statusinvest.com.br/acoes/'+acoes, headers=headers)
        tree = html.fromstring(page.content)
        percentagem_dividendo = "/html/body/main/div[2]/div/div[1]/div/div[4]/div/div[1]/strong"
        cotacao_atual = '//*[@id="main-2"]/div[2]/div/div[1]/div/div[1]/div/div[1]/strong'
        percentagem_dividendo = tree.xpath(percentagem_dividendo)[0].text
        cotacao_atual = tree.xpath(cotacao_atual)[0].text
        #percentagem_dividendo = percentagem_dividendo.replace(',','.')
        #print('Valor do Dividendo da',acoes,percentagem_dividendo)
        #print('Valor da cotacao atual da',acoes,cotacao_atual)
    except (requests.exceptions.Timeout, requests.exceptions.TooManyRedirects, requests.exceptions.RequestException) as e:
        return acoes,percentagem_dividendo, cotacao_atual
    return acoes, percentagem_dividendo, cotacao_atual

def statusinvest_fundos(FUNDO):
    fundo = FUNDO
    valor_do_dividendo, cotacao_atual = '0','0'
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    try:
        page = requests.get('https://statusinvest.com.br/fundos-imobiliarios/'+fundo, headers=headers)
        tree = html.fromstring(page.content)
        valor_do_dividendo = "/html/body/main/div[2]/div[1]/div[4]/div/div[1]/strong"
        #ultimo_recebimento = "/html/body/main/div[2]/div[7]/div[2]/div/div[1]/strong"
        cotacao_atual = '//*[@id="main-2"]/div[2]/div[1]/div[1]/div/div[1]/strong'
        valor_do_dividendo = tree.xpath(valor_do_dividendo)[0].text
        #ultimo_recebimento = tree.xpath(ultimo_recebimento)[0].text
        cotacao_atual = tree.xpath(cotacao_atual)[0].text
        #valor_do_dividendo = valor_do_dividendo.replace(',','.')
        #ultimo_recebimento = ultimo_recebimento.replace(',','.')
        #print(
        #'Fundo analisado:', fundo,"\n"+
        #'Valor do Dividendo:', valor_do_dividendo,"\n"+
        #'Ultimo Recebimento:',ultimo_recebimento,"\n"+
        #'Cotação Atual:',cotacao_atual)
    except (requests.exceptions.Timeout, requests.exceptions.TooManyRedirects, requests.exceptions.RequestException) as e:
        return fundo,valor_do_dividendo, cotacao_atual
    return fundo, valor_do_dividendo, cotacao_atual


def run_module():

    module_args = dict(
            statusinvest_acoes=dict(type='str', default='bbas3'), #required=True),
            statusinvest_fundos=dict(type='str', default='vghf11') #, required=True)
    )

    result = dict(
        changed=False,
        acoes={},
        fii={}
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if module.check_mode:
        module.exit_json(**result)

    result['acoes']['NAME'] = statusinvest_acoes(module.params['statusinvest_acoes'])[0]
    result['acoes']['DIVIDEND YIELD'] = statusinvest_acoes(module.params['statusinvest_acoes'])[1]
    result['acoes']['VALOR ATUAL'] = statusinvest_acoes(module.params['statusinvest_acoes'])[2]

    result['fii']['NAME'] = statusinvest_fundos(module.params['statusinvest_fundos'])[0]
    result['fii']['DIVIDEND YIELD'] = statusinvest_fundos(module.params['statusinvest_fundos'])[1]
    result['fii']['VALOR ATUAL'] = statusinvest_fundos(module.params['statusinvest_fundos'])[2]

    if module.params['statusinvest_acoes']:
        result['changed'] = True

    if module.params['statusinvest_fundos']:
        result['changed'] = True

    if module.params['statusinvest_acoes'] == 'fail me':
        module.fail_json(msg='You requested this to fail', **result)

    if module.params['statusinvest_fundos'] == 'fail me':
        module.fail_json(msg='You requested this to fail', **result)

    module.exit_json(**result)

def main():
    run_module()


if __name__ == '__main__':
    main()